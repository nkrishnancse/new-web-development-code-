#Responsive Blog Template

A simple two-column blog html layout based on the latest Bootstrap with custom navigation, header and thumbnail.
This template works seamlessly on all major web browsers, tablets and smartphones.

##Features

* Bootstrap v3.3.7
* HTML5 & CSS3
* Easy customizable
* Responsive
* SEO Optimized

<a href="https://easytousecode.github.io/bootstrap-blog-template/" targer="_blank">Live Demo</a>
<a href="https://github.com/easytousecode/bootstrap-blog-template/archive/gh-pages.zip" targer="_blank">Download</a>
